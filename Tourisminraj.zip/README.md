# Database Mangment and system

## Project Title - Tourism in Rajasthan
### Installation of Project

1. Python shloud be installed on your laptop
2. Then you need to install some libraries of python to run this project
3. Install Django - pip install django
4. Install pillow - pip install pillow

### Run the django server
1. Go to the directory in which manage.py file is there.
2. Then run command - python manage.py runserver
